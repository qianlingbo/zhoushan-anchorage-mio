#!/usr/bin/env python3
"""Calculate 15-minute River Mud Channel route windows for 2026."""

from __future__ import annotations

import argparse
import json
import sys
from datetime import date, timedelta
from pathlib import Path

YEAR = 2026
MIN_DRAFT = 16.0
CHANNEL_DRAFT = 20.0
SHALLOW_BASE = 16.4
DATA_PATH = Path(__file__).resolve().parent.parent / "assets" / "tide-data.json"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="按2026年河泥漕逐小时潮高计算15分钟粒度的浅滩/航槽时间。"
    )
    parser.add_argument("--draft", required=True, type=float, help="船舶吃水，单位米，须大于16")
    parser.add_argument("--date", required=True, help="日期，格式 YYYY-MM-DD，限2026年")
    parser.add_argument("--json", action="store_true", help="输出 JSON")
    parser.add_argument("--pretty", action="store_true", help="缩进格式化 JSON")
    return parser.parse_args()


def minute_text(minute: int) -> str:
    if minute == 1440:
        return "24:00"
    return f"{minute // 60:02d}:{minute % 60:02d}"


def tide_at(day: list[float], next_day: list[float] | None, minute: float) -> float:
    if minute >= 1440:
        return next_day[0] if next_day else day[23]
    hour = int(minute // 60)
    fraction = (minute % 60) / 60
    start = day[hour]
    end = (next_day[0] if next_day else start) if hour == 23 else day[hour + 1]
    return start + (end - start) * fraction


def classify(draft: float, tide: float) -> str:
    if draft >= CHANNEL_DRAFT:
        return "channel"
    limit = SHALLOW_BASE + tide
    if draft < limit:
        return "shallow"
    if draft > limit:
        return "channel"
    return "critical"


def merge_slots(slots: list[dict[str, int | str]]) -> list[dict[str, int | str]]:
    windows: list[dict[str, int | str]] = []
    for slot in slots:
        if windows and windows[-1]["route"] == slot["route"]:
            windows[-1]["end"] = slot["end"]
        else:
            windows.append(dict(slot))
    return windows


def calculate(draft: float, day_text: str) -> dict:
    try:
        selected = date.fromisoformat(day_text)
    except ValueError as error:
        raise ValueError("日期格式必须为 YYYY-MM-DD。") from error
    if selected.year != YEAR:
        raise ValueError("本 Skill 仅支持 2026-01-01 至 2026-12-31。")
    if draft <= MIN_DRAFT:
        raise ValueError("船舶吃水必须大于 16 m。")

    data = json.loads(DATA_PATH.read_text(encoding="utf-8"))
    key = selected.strftime("%m-%d")
    if key not in data:
        raise ValueError("未找到所选日期的河泥漕潮高数据。")
    following = selected + timedelta(days=1)
    next_key = following.strftime("%m-%d") if following.year == YEAR else None
    day = data[key]["h"]
    next_day = data[next_key]["h"] if next_key and next_key in data else None

    if draft >= CHANNEL_DRAFT:
        windows = [{"route": "channel", "start": 0, "end": 1440}]
    else:
        slots = []
        for index in range(96):
            start = index * 15
            route = classify(draft, tide_at(day, next_day, start + 7.5))
            slots.append({"route": route, "start": start, "end": start + 15})
        windows = merge_slots(slots)

    def select(route: str) -> list[str]:
        return [
            f"{minute_text(int(window['start']))}–{minute_text(int(window['end']))}"
            for window in windows
            if window["route"] == route
        ]

    return {
        "location": "河泥漕",
        "date": selected.isoformat(),
        "draft_m": draft,
        "required_tide_m": round(draft - SHALLOW_BASE, 2),
        "interval_minutes": 15,
        "shallow_windows": select("shallow"),
        "channel_windows": select("channel"),
        "critical_windows": select("critical"),
        "rules": {
            "shallow": "潮高 > 吃水 + 1.8m - 18.2m",
            "channel": "潮高 < 吃水 + 1.8m - 18.2m，或吃水 ≥ 20m",
        },
        "caution": "结果仅供通航计划辅助参考；实际操作请结合最新实测潮位、海况、航道通告及船长判断。",
    }


def text_report(result: dict) -> str:
    shallow = "、".join(result["shallow_windows"]) or "无"
    channel = "、".join(result["channel_windows"]) or "无"
    lines = [
        f"河泥漕 {result['date']}｜吃水 {result['draft_m']:g} m",
        f"所需潮高临界值：{result['required_tide_m']:g} m",
        f"允许过浅滩时间：{shallow}",
        f"需过航槽时间：{channel}",
    ]
    if result["critical_windows"]:
        lines.append(f"临界时间：{'、'.join(result['critical_windows'])}")
    lines.append(result["caution"])
    return "\n".join(lines)


def main() -> int:
    args = parse_args()
    try:
        result = calculate(args.draft, args.date)
    except (OSError, ValueError, json.JSONDecodeError) as error:
        print(f"错误：{error}", file=sys.stderr)
        return 2
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2 if args.pretty else None))
    else:
        print(text_report(result))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
