---
name: river-mud-channel-tide
description: Calculate 2026 River Mud Channel (河泥漕) vessel transit windows from a vessel's draft and date. Use when a user asks which 15-minute periods are suitable for passing the shallow route (过浅滩) or must use the channel (过航槽), including Codex, OpenClaw, Hermes, and other Agent Skills-compatible runtimes.
---

# River Mud Channel Tide

Use the bundled deterministic calculator. Do not estimate route windows from high/low-tide event times.

## Workflow

1. Obtain the vessel draft in metres and a date in 2026.
2. If either value is missing, ask only for the missing value.
3. Run:

```bash
python3 scripts/calculate_tide_route.py --draft 18.0 --date 2026-08-12 --json
```

When invoking from outside this skill directory, resolve `scripts/calculate_tide_route.py` relative to this `SKILL.md`.

4. Report the date, draft, required tide threshold, `shallow_windows`, and `channel_windows`. Preserve every returned time exactly.
5. Mention `critical_windows` only when the result contains them.
6. Include the operational caution from the result. Do not present this auxiliary calculation as a substitute for the vessel master's judgement or official navigation information.

## Rules

- Supported input: draft strictly greater than 16 m and date within 2026.
- Required tide threshold: `draft + 1.8 - 18.2`, equivalent to `draft - 16.4` metres.
- Shallow route: tide height is strictly greater than the threshold.
- Channel route: tide height is strictly less than the threshold.
- Draft greater than or equal to 20 m: channel route for the full day.
- Exact equality is a critical boundary, not a shallow-route or channel-route interval.
- The calculation interpolates consecutive hourly River Mud Channel tide heights and classifies all 96 quarter-hour slots using each slot midpoint.

## Output options

- Use `--json` for agent-readable structured output.
- Omit `--json` for a concise Chinese text report.
- Use `--pretty` together with `--json` for indented JSON.

