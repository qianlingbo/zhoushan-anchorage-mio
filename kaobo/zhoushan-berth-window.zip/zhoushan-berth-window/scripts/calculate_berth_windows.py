#!/usr/bin/env python3
"""Calculate Zhoushan berth windows from bundled 2026 Dinghai tide data."""
from __future__ import annotations

import argparse
import json
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TIDE_DATA = json.loads((ROOT / "references" / "tide-data.json").read_text(encoding="utf-8"))
DOCKS = json.loads((ROOT / "references" / "dock-rules.json").read_text(encoding="utf-8"))
DOCK_BY_ID = {dock["id"]: dock for dock in DOCKS}


def minutes(time: str) -> int:
    hour, minute = map(int, time.split(":"))
    return hour * 60 + minute


def clock(total: int) -> str:
    day = total // 1440
    minute = total % 1440
    label = f"{minute // 60:02d}:{minute % 60:02d}"
    if day == 1:
        return f"次日 {label}"
    if day == -1:
        return f"前日 {label}"
    if day:
        sign = "+" if day > 0 else ""
        return f"{sign}{day}日 {label}"
    return label


def offset_text(value: int) -> str:
    sign = "后" if value >= 0 else "前"
    value = abs(value)
    hour, minute = divmod(value, 60)
    parts = []
    if hour:
        parts.append(f"{hour}小时")
    if minute:
        parts.append(f"{minute}分钟")
    return sign + ("".join(parts) or "0分钟")


def duration_text(value: int) -> str:
    hour, minute = divmod(value, 60)
    return (f"{hour}小时" if hour else "") + (f"{minute}分钟" if minute else "") or "0分钟"


def tide_label(kind: str) -> str:
    return "高潮" if kind == "high" else "低潮"


def build_windows(date_key: str, dock: dict) -> list[dict]:
    tides = TIDE_DATA.get(date_key)
    if not tides:
        raise SystemExit(f"No tide data for {date_key}; use a 2026 date.")
    windows = []
    for rule in dock["windows"]:
        for index, tide in enumerate(t for t in tides if t["type"] == rule["ref"]):
            berth_abs = minutes(tide["time"]) + int(rule["offset"])
            report_abs = berth_abs - int(rule["pilot"])
            windows.append({
                "dock_id": dock["id"],
                "dock_name": dock["name"],
                "line": dock["line"],
                "distance": dock["distance"],
                "rule": rule["label"],
                "condition": rule.get("cond", ""),
                "dock_note": dock.get("note", ""),
                "berth_time": clock(berth_abs),
                "report_line_time": clock(report_abs),
                "reference_tide": {
                    "time": tide["time"],
                    "height": tide["height"],
                    "type": tide["type"],
                    "label": tide_label(tide["type"]),
                },
                "offset": rule["offset"],
                "offset_text": offset_text(int(rule["offset"])),
                "pilot_minutes": rule["pilot"],
                "pilot_text": duration_text(int(rule["pilot"])),
                "sort_minutes": berth_abs,
            })
    return sorted(windows, key=lambda item: item["sort_minutes"])


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--date", required=True, help="Date in YYYY-MM-DD format, within 2026")
    parser.add_argument("--dock", choices=sorted(DOCK_BY_ID), help="Dock ID; omit for all docks")
    parser.add_argument("--json", action="store_true", help="Print structured JSON")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    date = datetime.strptime(args.date, "%Y-%m-%d")
    if date.year != 2026:
        raise SystemExit("Only 2026 tide data is bundled.")
    date_key = f"{date.month:02d}-{date.day:02d}"
    selected = [DOCK_BY_ID[args.dock]] if args.dock else DOCKS
    result = {
        "date": args.date,
        "tides": TIDE_DATA[date_key],
        "docks": [
            {
                "dock_id": dock["id"],
                "dock_name": dock["name"],
                "line": dock["line"],
                "distance": dock["distance"],
                "note": dock.get("note", ""),
                "windows": build_windows(date_key, dock),
            }
            for dock in selected
        ],
    }
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return
    print(f"{args.date} 定海潮汐: " + " / ".join(f"{tide['time']} {tide_label(tide['type'])}{tide['height']}cm" for tide in result["tides"]))
    for dock in result["docks"]:
        print(f"\n{dock['dock_name']} ({dock['line']} {dock['distance']})")
        for item in dock["windows"]:
            cond = f"; {item['condition']}" if item["condition"] else ""
            print(
                f"- {item['rule']}: 靠泊 {item['berth_time']}, 到线 {item['report_line_time']}; "
                f"参考{item['reference_tide']['label']} {item['reference_tide']['time']} {item['offset_text']}; "
                f"航行 {item['pilot_text']}{cond}"
            )
        if dock["note"]:
            print(f"  注意: {dock['note']}")


if __name__ == "__main__":
    main()
