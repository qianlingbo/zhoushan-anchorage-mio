---
name: zhoushan-berth-window
description: Calculate Zhoushan port berth windows and report-line arrival times from 2026 Dinghai tide events and local dock rules. Use when the user asks about 舟山靠泊时间, 靠泊窗口, 到线时间, 定海潮汐, 舟山煤电, 舟山武港, 海港中奥, 金润石油, 华泰石油, 兴中岙山, 大鼎油储, 老塘山, 外钓油品, or 册子实华.
---

# Zhoushan Berth Window

Use this skill to answer berth-window questions for the 2026 Zhoushan port area.
The bundled data is based on the Dinghai sheet in `2026年每日潮高-每日高低潮新模板.xls`.

## Quick Start

For deterministic calculations, run:

```bash
python scripts/calculate_berth_windows.py --date 2026-08-04 --dock meidian
```

Useful options:

- `--date YYYY-MM-DD`: required.
- `--dock DOCK_ID`: optional. Omit it to return all docks.
- `--json`: return structured JSON instead of a short text table.

## Dock IDs

- `wugang`: 舟山武港
- `meidian`: 舟山煤电(六横)
- `zhongao`: 海港中奥
- `jinrun`: 金润石油
- `huatai`: 华泰石油
- `xingzhong`: 兴中岙山
- `dading`: 大鼎油储
- `laotangshan`: 老塘山
- `waidiao`: 外钓油品
- `cezi`: 册子实华

## Response Guidance

State the berth time first, then the report-line arrival time. Mention the
reference tide and rule offset so the result can be checked:

`初落(左靠): 靠泊 15:22, 到线 13:37, 参考 高潮 13:22 后2小时, 航行 1小时45分钟`

Use the dock notes and rule conditions exactly when they affect the answer,
especially tonnage and tide-size limitations.

## Data Files

- `references/tide-data.json`: 2026 Dinghai tide events by `MM-DD`.
- `references/dock-rules.json`: dock windows, offsets, pilot sailing times,
  report lines, distances, and notes.
